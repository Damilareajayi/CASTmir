const API_BASE_URL = 'https://5vpmkv6yjy.us-east-1.awsapprunner.com'

const screens = {
  unsupported: document.getElementById('unsupported'),
  authorize: document.getElementById('authorize'),
  consent: document.getElementById('consent'),
  dashboard: document.getElementById('dashboard'),
}

function show(name) {
  for (const [key, el] of Object.entries(screens)) el.classList.toggle('hidden', key !== name)
}

async function getUserHash() {
  const { castmir_user_hash } = await browser.storage.local.get('castmir_user_hash')
  return castmir_user_hash
}

async function dashboardUrl() {
  const hash = await getUserHash()
  return `${API_BASE_URL}/?hash=${encodeURIComponent(hash)}#user`
}

async function init() {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true })
  const site = await browser.runtime.sendMessage({ type: 'CASTmir_CHECK_SITE', url: tab?.url })

  if (!site.supported) {
    show('unsupported')
    return
  }

  if (!site.authorized) {
    document.getElementById('authorize-site').textContent = new URL(site.origin).hostname
    show('authorize')
    return
  }

  const { castmir_consented } = await browser.storage.local.get('castmir_consented')
  if (castmir_consented) {
    show('dashboard')
    loadDashboard()
  } else {
    show('consent')
    document.getElementById('alias-input').focus()
  }
}

document.getElementById('authorize-btn').addEventListener('click', async () => {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true })
  const site = await browser.runtime.sendMessage({ type: 'CASTmir_CHECK_SITE', url: tab?.url })
  const granted = await browser.runtime.sendMessage({ type: 'CASTmir_AUTHORIZE_SITE', origin: site.origin })
  if (granted) init() // re-evaluate — moves on to consent or dashboard
})

document.getElementById('alias-input').addEventListener('input', (e) => {
  document.getElementById('consent-btn').disabled = e.target.value.trim().length < 2
})

document.getElementById('consent-btn').addEventListener('click', async () => {
  const alias = document.getElementById('alias-input').value.trim()
  if (!alias) return

  const userHash = await getUserHash()
  await fetch(`${API_BASE_URL}/api/users/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user_hash: userHash, alias, extension_version: browser.runtime.getManifest().version }),
  }).catch(() => {}) // registration failure shouldn't block local consent

  await browser.storage.local.set({ castmir_consented: true, castmir_alias: alias })
  browser.runtime.sendMessage({ type: 'CASTmir_REFRESH_ICON' }) // next click opens the full dashboard, not this popup
  show('dashboard')
  loadDashboard()
})

async function loadDashboard() {
  const userHash = await getUserHash()
  try {
    const res = await fetch(`${API_BASE_URL}/api/user/${userHash}/dashboard`)
    const data = await res.json()

    const qualities = data.quality_trend?.map(r => r.quality).filter(Boolean) ?? []
    const pmis = data.pmi_trend?.map(r => r.pmi).filter(Boolean) ?? []
    const sessions = data.tool_breakdown?.reduce((sum, t) => sum + t.sessions, 0) ?? 0

    document.getElementById('kpi-quality').textContent =
      qualities.length ? `${Math.round(qualities.reduce((a, b) => a + b) / qualities.length)}%` : '—'
    document.getElementById('kpi-pmi').textContent =
      pmis.length ? (pmis.reduce((a, b) => a + b) / pmis.length).toFixed(1) : '—'
    document.getElementById('kpi-sessions').textContent = sessions

    const alertsEl = document.getElementById('alerts')
    for (const evt of (data.security_events ?? []).slice(0, 3)) {
      const div = document.createElement('div')
      div.className = 'alert-item'
      div.textContent = `${evt.severity.toUpperCase()} — ${evt.threat_type.replace(/_/g, ' ')}`
      alertsEl.appendChild(div)
    }
  } catch (err) {
    console.error('[CASTmir] popup dashboard fetch failed', err)
  }
}

document.getElementById('open-dashboard-btn').addEventListener('click', async () => {
  browser.tabs.create({ url: await dashboardUrl() })
})

init()
